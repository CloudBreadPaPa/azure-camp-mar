<?php
    $result = file_get_contents('http://requestb.in/13snx5e1');
    echo $result;
?>